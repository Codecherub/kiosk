<?php
if(isset($_POST['route'])){
    switch ($_POST['route']) {
        case 'auth':
            require "./socks/auth.php";
            break;
        case 'inventory':
            require "./socks/inventory.php";
            break;
        
        default:
        $res = array('status'=>"warning",
        'msg'=>"no router set for this request ".$_POST['route']."",
        "action"=>array("toast",""),
        "blob"=>"");
            break;
    }
} else {
    $res = array('status'=>"danger",
        'msg'=>"no router set for this request",
        "action"=>array("toast",""),
        "blob"=>"");
}




echo json_encode($res);
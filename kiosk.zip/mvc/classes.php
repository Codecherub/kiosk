<?php
 //database conn
 session_start();
 ini_set("display_errors",1);
 $db=mysqli_connect("localhost","root","","qs");
  

 class QS {
    
    //reconstruct mysql dtabase insert process
    function ins($columns,$values,$table) {
        //fetch db connection
        global $db;
        //verify if cols match values
        if(count(explode(',',$columns)) != count(explode(',',$values))){
            $this->res = false;
            $this->msg = 'unmatching entry limits';
        }else{
            if(mysqli_query($db,"insert into $table($columns) values($values)")){
                $this->res=true;
            }else{
                $this->res =false;
                $this->msg ='db insertion failed';
            }
        }
    }


    // compare two db values with entry values
    function com($comparison,$table,$num){
        global $db;
        if(mysqli_num_rows(mysqli_query($db,"select * from $table where $comparison")) > $num){
            $this->res = true;
        }
        else if(mysqli_num_rows(mysqli_query($db,"select * from $table where $comparison")) < 1){
            $this->res = false;
        }
    }

    //update db values
    function edit($updateSet,$idField,$id, $table){
        global $db;
        if(mysqli_query($db,"update $table set $updateSet where $idField = '$id'")){
            $this->res = true;
        }else
        {
            $this->res = false;
        }
    }

    //remove db row
    function del($query, $table){
        global $db;
        if(mysqli_query($db,"delete from $table  where $query")){
            $this->res = true;
        }else
        {
            $this->res = false;
        }
    }
    
    //get results
    function get($what){
        switch ($what) {
            case 'res':
                return $this->res;
                break;
            case 'msg':
                    return $this->msg;
                    break;
            
            default:
                # code...
                break;
        }
    }
}

 function fetcher($table,$col,$byCol,$id){
     global $db;
     $g = mysqli_query($db,"select * from $table where $byCol='$id' ");
     if(mysqli_num_rows($g) == 1){
     $get = mysqli_fetch_array($g);
     return $get[''.$col.''];
     }else {
         return "null";
     }
 }

function go($location,$time)
{
    echo "<script>setTimeout(function(){ location.assign('$location') },Number($time)*1000);</script>";
}

function xSTRING($str){ global $db;
    return mysqli_real_escape_string($db,$str);
 }


 function getMedia($uid){
    global $db;
    $m = mysqli_query($db,"select url  from media where uid='".$uid."' order by id desc ");
    while($get = mysqli_fetch_array($m)){
        $rows[] = $get;
    }
    if(count($rows)>0){
        return $rows;
    }else{
        return false;
    }
    
}

 ?>
<?php require "./classes.php";
 $data = new  QS();
 $res = array('status'=>"danger",
        'msg'=>"wow.. we didn't see that coming. ",
        "action"=>array("toast",""),
        "blob"=>"");
//  add new inventory
 if(isset($_POST['plugItem'])){
    $name = $_POST['plugItem'];
    $store = $_SESSION['store'];
    $cat = $_POST['cat'];
    $price = $_POST['price'];
    $url= $cat."-item-".rand(0,9999);
   //  $sock = $_POST['sock'];
    $detail = xSTRING($_POST['detail']);
    $uid = $_SESSION['uid'];
    $opt = $_POST['opt'];
    $media = getMedia($uid)[0]['url'];
    $data->com("name='$name' and store='$store'","items",0);
    if($data->get('res') === true){
        $res = array('status'=>"warning",
        'msg'=>"an item in your store already has this name",
        "action"=>array("toast",""),
        "blob"=>"");
    }
 
    else{
    $data->ins('name,store,category,price,uid,opt,url,detail',"'$name','$store','$cat','$price','$uid','$opt','$url','$detail'",'items');
    if($data->get('res') == true) {
        $res = array('status'=>"sux",
        'msg'=>"$name has been to your inventory",
        "action"=>array("toast","appendage"),
        "blob"=>array("appendage"=>array("<img src='media-assets/$media '>","$name","$cat","$price","$opt","0")));
        $_SESSION['uid']=md5("session".rand(0,999999));
    }
    else {
        $res = array('status'=>"danger",
        'msg'=>"something went terribly wrong ",
        "action"=>array("toast",""),
        "blob"=>"");
    }

   }

 }


 //new category
  if(isset($_POST['class'])){
    $name = str_replace(" ","-",$_POST['class']);
    $detail = $_POST['detail'];
    $store = $_SESSION['store'];
    
    $data->com("name='$name' and store='$store'","class",0);
    if($data->get('res') == true) {
        $res = array('status'=>"warning",
        'msg'=>"this classification already exists ",
        "action"=>array("toast",""),
        "blob"=>"");
    }
    else if(empty($_POST['class'])){
        $res = array('status'=>"warning",
        'msg'=>"invalid entry ",
        "action"=>array("toast",""),
        "blob"=>"");
    }
    else if($_POST['class'] === " "){
        $res = array('status'=>"warning",
        'msg'=>"invalid entry",
        "action"=>array("toast",""),
        "blob"=>"");
    }
    else{
   
    if(mysqli_query($db,"insert into class(name,detail,store) values('$name','$detail','$store')")) {
        $res = array('status'=>"sux",
        'msg'=>"$name has been added to your list for categories ",
        "action"=>array("toast","appendage"),
        "blob"=>array("appendage"=>array("$name","$detail","0")));
    }
    else {
        $res = array('status'=>"danger",
        'msg'=>"sorry, things didn't go as planned, pls try again  ",
        "action"=>array("toast",""),
        "blob"=>"");
    }
     }

}

//fetch stuff for editing
if(isset($_POST['fetcher'])){
    if($_POST['fetcher'] == 'class'){
        $id = $_POST['id'];
        $grab = mysqli_query($db,"select * from class where id='$id' ");
        while($get = mysqli_fetch_array($grab)){ 
            $rows[] = $get; }
            $res = array(
            "action"=>array("attach",""),
            "blob"=>array("attach"=>$rows));
    } else {
        $id = $_POST['id'];
        $grab = mysqli_query($db,"select * from items where id='$id' ");
        while($get = mysqli_fetch_array($grab)){ 
            $rows[] = $get; $imgs[]=getMedia($get["uid"]); }
            $res = array(
            "action"=>array("attach",""),
            "blob"=>array("attach"=>$rows,"imgs"=>$imgs));;
    }
}


//EDIT ITEM 
if(isset($_POST["XplugItem"])){
    $name = $_POST['XplugItem'];
    $cat = $_POST['cat'];
    $price = $_POST['price'];
    $detail = xSTRING($_POST['detail']);
    $id = $_POST['id'];
    $opt = $_POST['opt'];
    if(mysqli_query($db,"update items set name='$name' ,category='$cat',price='$price' ,detail='$detail', opt='$opt' where id='$id' ")){
        $res = array('status'=>"sux",
        'msg'=>"$name has been modified ",
        "action"=>array("toast",""),
        "blob"=>"");
    }else{
        $res = array('status'=>"danger",
        'msg'=>"something went terribly wrong ",
        "action"=>array("toast",""),
        "blob"=>"");
    }
}


// echo json_encode($res);
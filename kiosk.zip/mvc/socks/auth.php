<?php
require_once "./classes.php";

//signup auth 
if(isset($_POST['kioskemail']) && isset($_POST['kioskpassword'])){
    $check =mysqli_query($db,"select * from clients where email='".$_POST['kioskemail']."' and password ='".md5($_POST['kioskpassword'])."' ");
    if(mysqli_num_rows($check) == 1){
        $name = fetcher('clients','fullname','email',$_POST['kioskemail']);
        $res = array('status'=>"sux",
        'msg'=>"welcome Back $name",
        "action"=>array("toast","go"),
        "blob"=>array("go"=>"dashboard,2"));
        $_SESSION['client']=$_POST['kioskemail'];
    } else {
        $res = array('status'=>"warning",
        'msg'=>"invalid credentials, please confirm & try again ",
        "action"=>array("toast",""),
        "blob"=>"");
    }

}





else {
    $res = array('status'=>"warning",
    'msg'=>"incomplete routing parameters ",
    "action"=>array("toast",""),
    "blob"=>"");
}

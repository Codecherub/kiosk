<?php 

require_once '../classes.php';


if(!empty($_FILES)){
    $uid = $_SESSION['uid'];
    $tmpfile = $_FILES['file']['tmp_name'];
    $tf = "../../media-assets/".rand(0,9999).$_FILES['file']['name'];
    move_uploaded_file($tmpfile,$tf);
    $d= str_replace("media-assets/","",str_replace("../","",$tf));
    $data = new QS();
    $data->ins("url,uid","'$d','$uid'","media");
}
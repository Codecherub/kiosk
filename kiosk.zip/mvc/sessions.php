<?php
require_once "classes.php";
if(isset($_SESSION['client'])){
    $g = mysqli_query($db,"select * from clients where email='".$_SESSION['client']."' ");
    if(mysqli_num_rows($g) == 1){
    $getCli = mysqli_fetch_array($g);
    $_SESSION['store'] = $getCli['uID'];

    }else {
        session_destroy();
        header("location:login");
    }
}else {
    header("location:login");
}
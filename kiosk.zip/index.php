
<?php

require_once "./mvc/classes.php";

$request = $_SERVER['REQUEST_URI'];
$request = explode('/',$request);
$request = $request[2];

$pages = ["categories","inventory","orders","preferences","payouts","chat","login"];

  if($request === "" || $request === "dashboard"){
      require "./views/index.php";
  } 
  
  
  
  else {
      if(in_array($request,$pages)){
        include "./views/$request.php";
      }else {
        require "./views/404.html";
      }
  }
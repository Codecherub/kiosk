

$('.formal').submit(function(e){

    e.preventDefault(); // Prevent Default Submission
    formField = $(this).attr('id');
    $('#'+formField).css("opacity", ".9");

    $.ajax({
      url: 'mvc/router.php',
      type: 'POST',
      data: $(this).serialize() // it will serialize the form data
    })
    .done(function(data){
        data = JSON.parse(data);
        $('#' + formField).css("opacity", "1");
        
        console.log(data)
        //message handler
        if(jQuery.inArray("toast",data.action) > -1){
            toast(data.msg, data.status, 4);
        }

        //redirections
        if(jQuery.inArray("go",data.action) > -1){
          sub = data.blob["go"].split(',');
          go(sub[0],sub[1]);
        }

        //dataTable appendages
        if(jQuery.inArray("appendage",data.action) > -1){
         appData = data.blob['appendage'];
         appendage(appData);
        }
        
    })
    .fail(function(){
        toast('you seem to be offline', 'danger', 3);
            $('#' + formField).css("opacity", "1");
    });

  });

 $(document).ready(function(){
    $('.postmodify').click(function(){
        type = $(this).attr('data-type');
        id = $(this).attr('data-id');
        $.ajax({
            url: 'mvc/router.php',
            type: 'POST',
            data: 'route=inventory&fetcher='+type+'&id='+id// it will serialize the form data
          })
          .done(function(data){
            //   data = JSON.parse(data);
            data = JSON.parse(data);
            
            console.log(data)
            //message handler
            if(jQuery.inArray("toast",data.action) > -1){
                toast(data.msg, data.status, 3);
            }

            if(jQuery.inArray("attach",data.action) > -1){
               if(type === 'class'){
                   $('#name').val(data.blob['attach'][0].name);
                   $('#details').val(data.blob['attach'][0].detail);
               } else {
                $('#name').val(data.blob['attach'][0].name);
                $('#cat').val(data.blob['attach'][0].category);
                $('#cat').html(data.blob['attach'][0].category);
                $('#price').val(data.blob['attach'][0].price);
                $('#opt').val(data.blob['attach'][0].opt);
                $('#detail').val(data.blob['attach'][0].detail);
                $('#xID').val(data.blob['attach'][0].id);
                console.log(data.blob['imgs'].length+" "+data.blob['imgs'][0][0]['url'])   
                for(i=0; i<data.blob['imgs'].length; i++){
                  $('#imgs').append(
                    "<img src='media-assets/"+data.blob['imgs'][0][i]['url']+"' class='imgx col-xs-6 col-sm-4'>"
                  );
                }

               }
                
            }
              
             
              
          })
          .fail(function(){
              toast('unable to fetxh data', 'danger', 3);
                 
          });
    })
 })
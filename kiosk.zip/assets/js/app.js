$(document).ready(function(){

    //scroll
    $(document).scroll(function(){
        $('.header').addClass('headerShadow');
        setTimeout(function(){
            $('.header').removeClass('headerShadow');
        },5000)
    })

    // hamburger menu
    $('.ham').click(function(){
        $('.appMenu').show();
        appMenuClasses=$('.appMenu').attr('class').split(" ");
        console.log(jQuery.inArray("slideInLeft",appMenuClasses))
    if(jQuery.inArray("slideInLeft",appMenuClasses) < 1){
        $('.appMenu').toggleClass('slideInLeft');
        console.log(true)
        console.log(appMenuClasses)
    }
    else{
        
        $('.appMenu').toggleClass('  slideOutLeft ')
    }
        
       
    })


    //active menu items
    // $('.item').hover(function(){
    //     $('.item').removeClass('active animated fadeIn');
    //     $(this).addClass('active animated fadeIn')
    // })

    
    //close alert
    $('.alert').click(function(){
       $(this).fadeOut();
    })
    

    //modal controllers
   

    $('.modal-toggle').click(function(){
        $('#'+$(this).attr('data-modal')).fadeIn();
        $('body').attr('style','overflow:hidden');

    });

    function closeModal(){
        $('.modal').fadeOut();
        $('body').attr('style','overflow-y:scroll')

    };

    $('.closemodal').click(function(){
        closeModal();
    })
    
});



//toast messages
function toast(message,type,time){
    $('.alert').fadeOut();
    switch (type) {
        case "primary":
            icon = 'check-square';
            alert = 'Hey';
            break;
        case "danger":
            icon = 'alert-triangle';
            alert = 'darn it';
            break;
        case "warning":
            icon = 'alert-octagon';
            alert = 'Uh-oh';
            break;
        case "sux":
            icon = 'check-circle';
            alert = 'great';
            break;
    
        default:
            icon = 'check-circle';
            alert = 'done'
            break;
    }
    uid = Math.floor(Math.random()*100);
    if(time != "x"){
        setTimeout(function(){
            $('#alert-'+uid).fadeOut();
        },time*1000)
    }
    $('body').append('\
    <div id="alert-'+uid+'" class="alert animated slideInRight alert-'+type+'">\
    <div class="alert-head">\
        <span><i class="feather icon-'+icon+'"></i> <small>'+alert+'!</small></span> <span class="rightext" style="float: right; text-align: right;"><small class="">just now</small><i data-id="alert-'+uid+'" class="feather close-alert icon-x pl-10"></i></span>\
    </div>\
    <div class="alert-body">\
        <small>'+message+'</small>\
    </div>\
 </div>\
    ')
  
}

function go(url,time){
    setTimeout(function(){
        location.assign(url)
    },time*1000)
}

$('a').click(function(e){
    sessionStorage.setItem('active',$(this).attr('href'))
    // e.preventDefault();
    // $.get($(this).attr('href'),function(data){
    //     $('.main').html(data);
    // });
    // window.history.pushState("orders","new title",$(this).attr('href'))
})


    $('.item').removeClass('active animated fadeIn');
    $('#'+sessionStorage.getItem('active')).addClass('active animated fadeIn')
   
    $(document).ready(function(){
        $('.main').attr("style","opacity:1 !important")
    })


    $('body').append('<div class="ajaxLoader"></div>');
    setTimeout(function(){
            $('.ajaxLoader').attr('style','width:50%');
        },100)
    setTimeout(function(){
            $('.ajaxLoader').attr('style','width:75%');
        },800)
    setTimeout(function(){
        $('.ajaxLoader').attr('style','width:100%');
        $('.ajaxLoader').fadeOut('slow');
    },1200)


    function appendage(data){
        var t = $('#example').DataTable();
        t.row.add( data ).draw( false ); 
    }

 
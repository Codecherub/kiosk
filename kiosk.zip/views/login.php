<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <meta name="theme-color" content="#7131C1"> -->
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/flexboxgrid.min.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/feather/iconfont.css">
    <link rel="stylesheet" href="assets/css/plugins/animate/animate.min.css">
    <link rel="stylesheet" href="assets/plugins/jquery.dataTables.css">
    <link rel="stylesheet" href="assets/plugins/dropzone.css">
</head>
<body class="" >
    
    <div  class="row  enclose" style="position: fixed; width: 100%; height: 100%; z-index: 10 !important; background: transparent;"> <div class="col-md-4 col-sm-12"></div>
      <div class="col-md-4 col-xs-12">
          <div class="login-box card primary">
            <div class="login-logo">
                <p class="">ki<span class="t-info">o</span>sk</p>
            </div>
            <form class="formal" id="formal" autocomplete="off">
                <div class="col-i row">
                    <span class="feather icon-user col-xs-1"></span>
                    <input required type="email" name="kioskemail" class="col-xs-11 t-white" placeholder="email address">
                </div>
                <div class="col-i row">
                    <span class="feather icon-lock col-xs-1"></span>
                    <input type="hidden" name="route" value="auth">
                    <input  id="<?php echo rand(0, 9999); ?>" required type="password" name="kioskpassword"  class="col-xs-11 t-white" placeholder="password">
                </div>
                <div class=" row" style="margin:0px 20px">
                    <div class="col-xs-6"></div>
                    <div class="col-xs-6 rightext"><small>forgot password?</small></div>
                </div>
                <div class="row" style="margin:20px 20px; padding: 10px;">
                    <div class="col-xs-3"></div>
                    <button class="white a-btn col-xs-6">Proceed</button>
                </div>
                <div class="row" style="margin:20px 20px; padding: 10px;">
                    <div class="col-xs-3"></div>
                    <a style="font-family:appFont !important" class="col-xs-6 feather centext"><i class="feather icon-users t-info"></i> Sign up</a>
                </div>
                <pre>
                    
                </pre>
            </form>
          </div>
          

       
         
      </div>
    </div>
    <span class="lager">
        <i class="feather icon-trending-up"></i>
        <i class="feather icon-tag"></i>
        <i class="feather icon-message-square"></i>
        <i class="feather icon-activity"></i>
        <i class="feather icon-users"></i>
        <i class="feather icon-life-buoy"></i>
        <i class="feather icon-target"></i>
        <i class="feather icon-shopping-cart"></i>
        <i class="feather icon-sun"></i>
        <i class="feather icon-activity"></i>
        <i class="feather icon-users"></i>
        <i class="feather icon-trending-up"></i>
        <i class="feather icon-tag"></i>
        <i class="feather icon-repeat"></i>
        <i class="feather icon-sun"></i>
        <i class="feather icon-life-buoy"></i>
        <i class="feather icon-target"></i>
        <i class="feather icon-shopping-cart"></i>
        <i class="feather icon-sun"></i>
        <i class="feather icon-activity"></i>
        <i class="feather icon-users"></i>
        <i class="feather icon-trending-up"></i>
        <i class="feather icon-tag"></i>
        <i class="feather icon-shopping-cart"></i>
        <i class="feather icon-sun"></i>
        <i class="feather icon-life-buoy"></i>
        <i class="feather icon-target"></i>
        <i class="feather icon-trending-up"></i>
        <i class="feather icon-tag"></i>
        <i class="feather icon-message-square"></i>
        <i class="feather icon-activity"></i>
        <i class="feather icon-users"></i>
        <i class="feather icon-life-buoy"></i>
        <i class="feather icon-target"></i>
        <i class="feather icon-trending-up"></i>
        <i class="feather icon-tag"></i>
        <i class="feather icon-message-square"></i>
        <i class="feather icon-lock"></i>
        <i class="feather icon-users"></i>
        <i class="feather icon-life-buoy"></i>
        <i class="feather icon-target"></i>
        <i class="feather icon-shopping-cart"></i>
        <i class="feather icon-sun"></i>
        <i class="feather icon-activity"></i>
        <i class="feather icon-users"></i>
        <i class="feather icon-trending-up"></i>
        <i class="feather icon-tag"></i>
        <i class="feather icon-shopping-cart"></i>
        <i class="feather icon-sun"></i>
        <i class="feather icon-life-buoy"></i>
        <i class="feather icon-target"></i>
        <i class="feather icon-monitor"></i>
        <i class="feather icon-sun"></i>
        <i class="feather icon-activity"></i>
        <i class="feather icon-users"></i>
        <i class="feather icon-life-buoy"></i>
        <i class="feather icon-target"></i>
        <i class="feather icon-shopping-cart"></i>
        <i class="feather icon-sun"></i>
        <i class="feather icon-activity"></i>
        
       
    </span>
   
</body>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/formal.js"></script>
<script>

</script>
</html>
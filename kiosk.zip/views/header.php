<?php include "mvc/sessions.php"; ?>
<div class="col-xs-12 col-md-3 appMenu animated ">
            <div class="col-xs-6 col-md-10  contain"><i class="feather ham icon-x"></i></div>
            <div class="logo part center">
                <h3><i class="icon-feather feather"></i> Ki<span class="t-primary">o</span>sk</h3>
            </div>
            <div class="menuList">
                <div class="sub">discover</div>
                <ul>
                   <a href="dashboard"><li id="dashboard" class="item"><i class="icon-activity feather "> </i>Dashboard</li></a>
                    <a href="chat"><li  id="chat" class="item active"><i class="icon-message-square feather "> </i>Chat</li></a>
                    <a href="payouts"><li id="payouts" class="item"><i class="icon-credit-card feather "> </i>payouts</li></a>
                </ul>

                <div class="sub">store keeper</div>
                <ul>
                <a href="inventory"><li id="inventory" class="item animated fadeIn"><i class="icon-shopping-cart feather "> </i>inventory</li></a>
                <a href="categories"><li id="categories" class="item "><i class="icon-more-horizontal feather "> </i>Categories</li></a>
                <a href="orders"><li id="orders" class="item"><i class="icon-layers feather "> </i>orders</li></a>
                <a href="preferences"><li id="preferences" class="item"><i class="icon-settings feather "> </i>Preferences</li></a>
                </ul>
            </div>
        </div>
        <div class="col-xs-12 ">
        <div class="header">
            <div class="contain">
                <div class="row">
                    <i class="feather col-xs-6 ham icon-grid"></i>
                    <div class="col-xs-6 forBig col-sm-8 col-md-10">
                        <a href="inevtory#new" class="ic-list ">
                            <i class="feather t-primary icon-life-buoy"></i>
                            <span>Support</span>
                        </a>
                        <a href="analytics" class="ic-list ">
                            <i class="feather  icon-pie-chart  t-PRIMARY"></i>
                            <span>Analytics</span>
                        </a>
                    </div>
                    <div class="col-md-2 col-sm-4 col-xs-6">
                        <div class="right">
                        <span class="zero warning"><?php echo  str_split($getCli['shopname'])[0]; ?></span> 
                        <span class="name"><?php echo $getCli['shopname']; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
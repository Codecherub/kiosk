<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/flexboxgrid.min.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/feather/iconfont.css">
    <link rel="stylesheet" href="assets/css/plugins/animate/animate.min.css">
    <link rel="stylesheet" href="assets/plugins/jquery.dataTables.css">
    <link rel="stylesheet" href="assets/plugins/dropzone.css">
</head>

<body>
    <div class="row enclose">
        <?php include "header.php"; ?>
        <div class="main">
            <div class="contain">
                <div class="row">
                    <div class="col-xs-6">
                        <div class="breadCrumb">
                            <span>Categories</span>
                            <span class="t-primary">Home <i class="feather icon-compass"></i></span>
                            <span>Categories</span>
                        </div>
                    </div>
                    <div class="col-xs-6 pt-20">
                        <div class="pt-20"></div>
                        <button data-modal="newDataModal" class="btn-r primary rightext modal-toggle"> <i
                                class="feather icon-plus"></i> Add New</button>
                    </div>





                </div>
                <div class="col-md-12  ">
                    <table id="example" class=" ">
                        <thead>
                            <tr>

                                <th>Category name</th>
                                <th>category tags</th>
                                <th>Items in category</th>

                            </tr>
                        </thead>
                        <tbody>


                        </tbody>
                    </table>
                </div>


            </div>
        </div>
    </div>
    </div>
    </div>

    <div class="modal" id="newDataModal">
        <div class="modal-header animated slideInRight">
            <div class="row">
                <div class="col-xs-3">
                    <p class="feather closemodal icon-arrow-left">
                        </>
                </div>
                <div class="col-xs-9">
                    <p class="rightext">New Category</p>
                </div>
            </div>
        </div>

        <button onclick="$('#newcat').submit()" class="modal-footer but primary animated slideInRight">
            add Category
        </button>

        <div class="cover closemodal"></div>
        <div class="righted animated slideInRight">

            <!-- method="POST" action="mvc/socks/inventory.php" -->
            <div class="contained">
                <form class="form row formal" id="newcat" method="POST" action="mvc/socks/inventory.php">

                    <div class="col-xs-12">
                        <label>Category Name</label>
                        <input required name="class" placeholder="item name">
                    </div>

                    <input type="hidden" name="route" value="inventory">


                    <div class="col-xs-12">
                        <label>Category Tags <small> *separate with commas(,)</small></label>
                        <textarea name="detail" rows="6" type="number" placeholder=""></textarea>
                    </div>






                </form>

            </div>

        </div>
    </div>

    <div class="modal" id="postDataModal">
        <div class="modal-header animated slideInRight">
            <div class="row">
                <div class="col-xs-3">
                    <p class="feather closemodal icon-arrow-left">
                        </>
                </div>
                <div class="col-xs-9">
                    <p class="rightext">Modify Category</p>
                </div>
            </div>
        </div>

        <button onclick="$('#postcat').submit()" class="modal-footer but primary animated slideInRight">
            modify
        </button>

        <div class="cover closemodal"></div>
        <div class="righted animated slideInRight">

            <!-- method="POST" action="mvc/socks/inventory.php" -->
            <div class="contained">
                <form class="form row formal" id="postcat" method="POST" action="mvc/socks/inventory.php">

                    <div class="col-xs-12">
                        <label>Category Name</label>
                        <input id="name" required name="class" placeholder="item name">
                    </div>

                    <input  type="hidden" name="route" value="inventory">


                    <div class="col-xs-12">
                        <label>Category Tags <small> *separate with commas(,)</small></label>
                        <textarea id="details" name="detail" rows="6" type="number" placeholder=""></textarea>
                    </div>






                </form>

            </div>

        </div>
    </div>

</body>
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/app.js"></script>
<script src="./assets/plugins/jquery.dataTables.js"></script>

<script src="./assets/js/formal.js"></script>
<script>
    $(document).ready(function () {
        $('#example').DataTable();

    });

    // $("div#Xzone").dropzone({ url: "/file/post" });
    // toast("hello world this is a test","sux",2000)
</script>
<?php
 $g =  mysqli_query($db,"select * from class where store = '".$_SESSION['store']."'");
 while($get=mysqli_fetch_array($g)){   $rows[] = $get; } 
 echo "<script> rows=".json_encode($rows)."; </script>"; ?>
<script>
    for (i = 0; i < rows.length; i++) {
        $('tbody').prepend("<tr data-id='" + rows[i].id + "' data-type='class' data-modal='postDataModal' class='modal-toggle postmodify'>\
     <td> " + rows[i].name + " </td>\
     <td> " + rows[i].detail.replace(",", " ").replace(",", " ") + " </td>\
     <td> " + Math.floor(Math.random() * 100) + " </td>\
     ");
    }


</script>


</html>
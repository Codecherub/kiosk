<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/flexboxgrid.min.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/feather/iconfont.css">
    <link rel="stylesheet" href="assets/css/plugins/animate/animate.min.css">
    <link rel="stylesheet" href="assets/plugins/jquery.dataTables.css">
    <link rel="stylesheet" href="assets/plugins/dropzone.css">
</head>

<body>
    <div class="row enclose">
        <?php include "header.php"; ?>
        <div class="main">
            <div class="contain">
                <div class="row">
                    <div class="col-xs-6">
                        <div class="breadCrumb">
                            <span>inventory</span>
                            <span class="t-primary">Home <i class="feather icon-compass"></i></span>
                            <span>Inventory</span>
                        </div>
                    </div>
                    <div class="col-xs-6 pt-20">
                        <div class="pt-20"></div>
                        <button data-modal="newDataModal" class="btn-r primary rightext modal-toggle"> <i
                                class="feather icon-plus"></i> Add New</button>
                    </div>





                </div>
                <div class="col-md-12  ">
                    <table id="example" class=" ">
                        <thead>
                            <tr>
                                <th></th>
                                <th>name</th>
                                <th>category</th>
                                <th>price</th>
                                <th>In Stock</th>
                                <th>purchases</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                           
                            

                        </tbody>
                    </table>
                </div>


            </div>
        </div>
    </div>
    </div>
    </div>

    <div class="modal" id="newDataModal">
        <div class="modal-header animated slideInRight">
            <div class="row">
                <div class="col-xs-3">
                    <p class="feather closemodal icon-arrow-left">
                        </>
                </div>
                <div class="col-xs-9">
                    <p class="rightext">New Item</p>
                </div>
            </div>
        </div>
        <button onclick="$('#newitem').submit()" class="modal-footer but primary animated slideInRight">
            add item
        </button>
        <div class="cover closemodal"></div>
        <div class="righted animated slideInRight">


            <div class="contained">
                <form class="form row formal" id="newitem">

                    <div class="col-xs-12">
                        <label>Item Name</label>
                        <input required name="plugItem" maxlength="15" placeholder="item name">
                        <input type="hidden" name="route" value="inventory">
                    </div>
                    <div class="col-xs-12">
                        <label>Item Category</label>
                        <select placeholder="item name" required name="cat">
                            <?php 
                                 $grab = mysqli_query($db,"select * from class where store='".$_SESSION['store']."' ");
                                 while($get = mysqli_fetch_array($grab)){ 
                                 echo "<option value='".$get['name']."'>".$get['name']."</option>"; }?>
                            <option>uncategorized</option>
                        </select>
                    </div>
                    <div class="col-xs-5">
                        <label>Item Price</label>
                        <input type="number" required name="price" maxlength="6" placeholder="">
                    </div>
                    <div class="col-xs-1">

                    </div>
                    <div class="col-xs-5">
                        <label>Items in Stock</label>
                        <input type="number" name="opt" placeholder=" ">
                    </div>
                    <div class="col-xs-12">
                        <label>Item DESCRIPTION</label>
                        <textarea name="detail" maxlength="25" rows="6" type="number" placeholder=""></textarea>
                    </div>






                </form>
                <div id="Xzone" class="form">
                    <br />
                    <label>Images</label>
                </div>
                <form action="mvc/socks/fmgr.php" id="drop" class="dropzone ">
                    <div class="fallback">
                        <input name="file" type="file" multiple />
                    </div>
                </form>
            </div>

        </div>
    </div>


    <div class="modal" id="postDataModal">
        <div class="modal-header animated slideInRight">
            <div class="row">
                <div class="col-xs-3">
                    <p class="feather closemodal icon-arrow-left">
                        </>
                </div>
                <div class="col-xs-9">
                    <p class="rightext">Modify Item</p>
                </div>
            </div>
        </div>
        <button onclick="$('#postitem').submit()" class="modal-footer but primary animated slideInRight">
        Modify item
        </button>
        <div class="cover closemodal"></div>
        <div class="righted animated slideInRight">


            <div class="contained">
                <form class="form row formal" id="postitem">

                    <div class="col-xs-12">
                        <label>Item Name</label>
                        <input id="name"  required name="XplugItem" maxlength="25" placeholder="item name">
                        <input  type="hidden" name="route" value="inventory">
                        <input  type="hidden" id="xID" name="id" value="">
                    </div>
                    <div class="col-xs-12">
                        <label>Item Category</label>
                        <select  placeholder="item name" required name="cat">
                        <option id="cat"></option>
                            <?php 
                                 $grab = mysqli_query($db,"select * from class where store='".$_SESSION['store']."' ");
                                 while($get = mysqli_fetch_array($grab)){ 
                                 echo "<option value='".$get['name']."'>".$get['name']."</option>"; }?>
                            <option>uncategorized</option>
                        </select>
                    </div>
                    <div class="col-xs-5">
                        <label>Item Price</label>
                        <input id="price" type="number" required name="price" maxlength="6" placeholder="">
                    </div>
                    <div class="col-xs-1">

                                 </div>
                    <div class="col-xs-5">
                        <label>Items in Stock</label>
                        <input id="opt" type="number" name="opt" placeholder=" ">
                    </div>
                    <div class="col-xs-12">
                        <label>Item DESCRIPTION</label>
                        <textarea id="detail" name="detail" maxlength="205" rows="6" type="number" placeholder=""></textarea>
                    </div>






                </form>
                <div class=row id=imgs></div>
               
            </div>

        </div>
    </div>

</body>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/plugins/jquery.dataTables.js"></script>
<script src="assets/plugins/dropzone.js"></script>
<script src="assets/js/formal.js"></script>
<script>
    $(document).ready(function () {
        $('#example').DataTable();

    });

  

   

    // toast("hello world this is a test","danger",2000)
    Dropzone.options.drop = {
        paramName: "file", // The name that will be used to transfer the file
        maxFiles: 5, // MB
        maxFilesize: 1,
        thumbnailWidth: 100,
        thumbnailHeight: 100,
        accept: function (file, done) {
            if (file.name == "justinbieber.jpg") {
                done("Naha, you don't.");
            } else {
                done();
            }
        }
    };
</script>
<?php
 $g =  mysqli_query($db,"select * from items where store = '".$_SESSION['store']."'");
 while($get=mysqli_fetch_array($g)){   $rows[] = $get; $media[]=getMedia($get['uid'])[0]['url']; } 
 echo "<script> rows=".json_encode($rows)."; media=".json_encode($media)."</script>"; ?>
<script>
    for(i=0; i<rows.length; i++){
     $('tbody').prepend("<tr  data-id='" + rows[i].id + "' data-type='item' data-modal='postDataModal' class='modal-toggle postmodify'>\
     <td><img src='media-assets/"+media[i]+"'>\
     <td> "+rows[i].name+" </td>\
     <td> "+rows[i].category+" </td>\
     <td> "+rows[i].price+" </td>\
     <td> "+rows[i].opt+" </td>\
     <td> "+rows[i].purchases+" </td>\
     </tr>");
    }
</script>

<?php $_SESSION['uid'] = md5(rand(0,99999)); ?>

</html>
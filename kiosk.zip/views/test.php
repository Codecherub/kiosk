<!DOCTYPE html>
<html>
<head>
<style>
table {
    border-collapse: separate;
     border-spacing: 10px 50px;
     
}

table, td, th {
    border: 1px solid black;
}
</style>
</head>
<body>

<table>
  <tr>
    <th>Firstname</th>
    <th>Lastname</th>
  </tr>
  <tr>
    <td>Peter</td>
    <td>Griffin</td>
  </tr>
  <tr>
    <td>Lois</td>
    <td>Griffin</td>
  </tr>
</table>

<p><b>Note:</b> If a !DOCTYPE is not specified, the border-collapse property can produce unexpected results 
in IE8 and earlier versions.</p>

</body>

<!-- Mirrored from www.w3schools.com/cssref/tryit.asp?filename=trycss_table_border-collapse by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 23 Jan 2015 07:50:38 GMT -->
</html>

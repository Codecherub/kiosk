<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/flexboxgrid.min.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/feather/iconfont.css">
    <link rel="stylesheet" href="assets/css/plugins/animate/animate.min.css">
    <link rel="stylesheet" href="assets/plugins/jquery.dataTables.css">
</head>
<body>
    <div class="row enclose">
       <?php include "header.php"; ?>
        <div class="main">
            <div class="contain">
                <div class="row">
                    <div class="col-md-6 col-xs-12">
                        <div class=" card primary">
                            <div class="card-body row">
                               <div class="col-xs-3 centext">
                                <i class="t-primary tlarge round white feather icon-feather"></i>
                               </div>
                               <div class="col-xs-9 lead">
                                   <b class="t-info">Howdy</b> Topher
                               </div>
                               <div class="col-xs-12 centext pt-20">
                                You have done 57.6% more sales today. Check your new badge in your profile.
                               </div>
                               <div class="col-xs-12">
                                <span class="modifyer">HELLO</span>
                               </div>
                               

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12">
                        <div class=" card warning">
                            <div class="card-body row">
                                
                                <div class="col-xs-3 centext">
                                 <i class="t-white tlarge round primary feather icon-layers"></i>
                                </div>
                                <div class="col-xs-9 centext ">
                                    <b class="t-white lead">+</b> <span class="lead">Shopping Items</span><br/>
                                    <b class="smalltext t-white">20 completed</b>
                                </div>
                                
                                 <span class="modifyer t-white">30+</span>
                                
 
                             </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12">
                        <div class=" card danger">
                            <div class="card-body row">
                                
                                <div class="col-xs-3 centext">
                                 <i class="t-white tlarge round primary feather icon-package"></i>
                                </div>
                                <div class="col-xs-9 centext ">
                                    <b class="t-white lead">+50</b> <span class="lead">Pending orders</span><br/>
                                    <b class="smalltext t-white">20 completed</b>
                                </div>
                                
                                 <span class="modifyer t-white">50</span>
                                
 
                             </div>
                        </div>
                    </div>
                    <div

                    <section class="col-md-12">
                        
                            <div class="col-md-12"><h3 class="hh">Recent Items</h3></div>
                            <center class="">
                            <div class="row preList">
                            <div class="col-xs-6 card col-md-4">
                                <div class="row">
                                    <div class="col-xs-12 col-md-6">
                                        <img src="./assets/img/6475apple-watch.png">
                                    </div>
                                    <div class="col-xs-12 col-md-6">
                                        <div class="break">
                                            <span class="priceX">$150</span>
                                            <span class="nameX">Apple Watch</span>
                                            <span class="classX info">category</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-xs-6 card col-md-4">
                                <div class="row">
                                    <div class="col-xs-12 col-md-6">
                                        <img src="./assets/img/1598iphone-x.png">
                                    </div>
                                    <div class="col-xs-12 col-md-6">
                                        <div class="break">
                                            <span class="priceX">$250</span>
                                            <span class="nameX">iphone xs max</span>
                                            <span class="classX info">category</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-6 col-md-4 card">
                                <div class="row">
                                    <div class="col-xs-12 col-md-6">
                                        <img src="./assets/img/2042ipad-pro.png">
                                    </div>
                                    <div class="col-xs-12 col-md-6">
                                        <div class="break">
                                            <span class="priceX">$250</span>
                                            <span class="nameX">ipad pro</span>
                                            <span class="classX info">category</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 ham col-md-4 card">
                                <div class="row">
                                    <div class="col-xs-12 col-md-6">
                                        <img src="./assets/img/2042ipad-pro.png">
                                    </div>
                                    <div class="col-xs-12 col-md-6">
                                        <div class="break">
                                            <span class="priceX">$250</span>
                                            <span class="nameX">ipad pro</span>
                                            <span class="classX info">category</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            </div>

                            
                        </center>
                    </div>

                        
                    <div class="col-xs-12  ">
                        <table id="example" class=" ">
                            <thead >
                                <tr>
                                    <th>id</th>
                                  <th>order_id</th>
                                  <th>date</th>
                                  <th>total</th>
                                  <th>status</th>
                                  <th>this</th>
                                  <th>that</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>   
        </div>
    </div>
   
</body>
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/app.js"></script>
<script src="./assets/plugins/jquery.dataTables.js"></script>

<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );

for(i=0; i<50; i++){
    $('tbody').prepend('<tr><td>'+i+'<td>ovh-71425368</td><td>may 17 2019</td>\
                                    <td>2500</td> <td>pending</td><td>pending</td><td>pending</td>\
                                </tr>');
}
</script>
</html>
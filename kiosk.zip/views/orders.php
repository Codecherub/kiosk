<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/flexboxgrid.min.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/feather/iconfont.css">
    <link rel="stylesheet" href="assets/css/plugins/animate/animate.min.css">
    <link rel="stylesheet" href="assets/plugins/jquery.dataTables.css">
    <link rel="stylesheet" href="assets/plugins/dropzone.css">
</head>
<body>
    <div class="row enclose">
    <?php include "header.php"; ?>
        <div class="main">
            <div class="contain">
                <div class="row">
                   <div class="col-xs-6">
                       <div class="breadCrumb">
                           <span>Categories</span>
                           <span class="t-primary">Home <i class="feather icon-compass"></i></span>
                           <span>Categories</span>
                       </div>
                   </div>
                   <div class="col-xs-6 pt-20">
                       <div class="pt-20"></div>
                       <button data-modal="newDataModal" class="btn-r primary rightext modal-toggle"> <i class="feather icon-plus"></i> Add New</button>
                   </div>
                    

                    
                        
                           
                </div> 
                <div class="col-md-12  ">
                    <table id="example" class=" ">
                        <thead >
                            <tr>
                             
                              <th>Category name</th>
                              <th>category tags</th>
                              <th>Items in category</th>
                              
                            </tr>
                        </thead>
                        <tbody>
                            
                           
                        </tbody>
                    </table>
                </div>

                     
                </div>
            </div>
        </div>   
        </div>
    </div>

    <div class="modal" id="newDataModal">
        <div class="modal-header animated slideInRight">
            <div class="row">
                <div class="col-xs-3">
                    <p  class="feather closemodal icon-arrow-left"></>
                </div>
                <div class="col-xs-9">
                    <p class="rightext">New Category</p>
                </div>
            </div>
        </div>
        
        <div class="cover closemodal"></div>
        <div class="righted animated slideInRight">
            
         
            <div class="contained">
                <form class="form row">
                   
                        <div class="col-xs-12">
                            <label>Category Name</label>
                            <input placeholder="item name">
                        </div>
                        
                        <div class="col-xs-12">
                            <label>Category Tags <small> *separate with commas(,)</small></label>
                            <input type="number" placeholder="item name">
                        </div>
                        <div class="col-xs-1">
                            
                        </div>
                        <div class="col-xs-12">
                            <label>Category DESCRIPTION</label>
                            <textarea rows="6" type="number" placeholder=""></textarea>
                        </div>
                        

                        
                            
                        
                        <button class="modal-footer but primary animated slideInRight">
                            add Category
                        </button>
                </form>
               
            </div>
          
            </div>
    </div>
   
</body>
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/app.js"></script>
<script src="./assets/plugins/jquery.dataTables.js"></script>
<script>
    $(document).ready(function() {
    $('#example').DataTable();
    
} );

cat = ["mobiles","electronics","computer","fashion","kitchen","others"];
tags = ["phones,tablet,acces","tv,fridge,Gen","men,women,children","fashion","utensils,gadget,spoons","auxillary,gymn,home"];
count = ["10","5","120","11","30","25"];
for(i=0; i<cat.length; i++){
    $('tbody').append('<tr><td>'+cat[i]+' </td><td>'+tags[i]+' </td><td>'+count[i]+' </td>\
                                </tr>');
}

// $("div#Xzone").dropzone({ url: "/file/post" });
// toast("hello world this is a test","danger",2000)
</script>
</html>